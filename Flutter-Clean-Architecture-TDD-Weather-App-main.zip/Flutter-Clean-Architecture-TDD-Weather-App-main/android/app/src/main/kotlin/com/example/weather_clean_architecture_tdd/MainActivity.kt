package com.example.weather_clean_architecture_tdd

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
